import 'package:flutter/material.dart';
import '../services/local_storage.dart';

class OrderProvider extends ChangeNotifier {
  List<Map<String, dynamic>> _orders = [];

  List<Map<String, dynamic>> get orders => _orders;

  OrderProvider() {
    _load();
  }

  Future<void> _load() async {
    _orders = await LocalStorage.readOrders();
    notifyListeners();
  }

  Future<void> addOrder({
    required List<Map<String, dynamic>> items,
    required double total,
  }) async {
    final newOrder = {
      'id': _orders.isNotEmpty ? _orders.first['id'] + 1 : 1,
      'items': items,
      'total': total,
      'date': DateTime.now().toString().substring(
        0,
        19,
      ), // Format YYYY-MM-DD HH:MM:SS
    };
    _orders.insert(0, newOrder);
    await LocalStorage.saveOrders(_orders);
    notifyListeners();
  }
}
