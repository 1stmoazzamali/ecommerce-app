class Product {
  final int id;
  final String title;
  final double price;
  final String description;
  final String category;
  final String image;
  final double rating;
  final int ratingCount;

  Product({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    required this.category,
    required this.image,
    required this.rating,
    required this.ratingCount,
  });

  factory Product.fromJson(Map<String, dynamic> j) => Product(
    id: j['id'],
    title: j['title'],
    price: (j['price'] as num).toDouble(),
    description: j['description'],
    category: j['category'],
    image: j['image'],
    rating: j['rating'] != null ? (j['rating']['rate'] as num).toDouble() : 0.0,
    ratingCount: j['rating'] != null ? (j['rating']['count'] as int) : 0,
  );
}
