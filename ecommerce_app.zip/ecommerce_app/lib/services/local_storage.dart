import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class LocalStorage {
  static const _ordersKey = 'orders';

  static Future<void> saveOrders(List<Map<String, dynamic>> orders) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(_ordersKey, jsonEncode(orders));
  }

  static Future<List<Map<String, dynamic>>> readOrders() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_ordersKey);
    if (s == null) return [];
    final list = jsonDecode(s) as List;
    return List<Map<String, dynamic>>.from(list);
  }
}
