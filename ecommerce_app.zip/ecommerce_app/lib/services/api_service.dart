import 'package:dio/dio.dart';
import '../models/product.dart';

class ApiService {
  final Dio _dio = Dio(BaseOptions(baseUrl: 'https://fakestoreapi.com'));

  Future<List<Product>> fetchProducts() async {
    final res = await _dio.get('/products');
    final data = res.data as List;
    return data.map((e) => Product.fromJson(e)).toList();
  }

  Future<Product> fetchProductById(int id) async {
    final res = await _dio.get('/products/$id');
    return Product.fromJson(res.data);
  }
}
